import { cn } from "@/lib/utils";
import type { Shift } from "@/lib/flights";

interface ShiftFilterProps {
  value: Shift | null;
  onChange: (value: Shift | null) => void;
  className?: string;
}

const OPTIONS: { value: Shift | null; label: string; hint: string }[] = [
  { value: null, label: "Alle", hint: "Hele døgnet" },
  { value: "day", label: "Dagskift", hint: "04:00-16:00" },
  { value: "night", label: "Kveldskift", hint: "15:00-04:00 (+1)" },
];

/** Segmented control that narrows the board to one shift. */
export function ShiftFilter({ value, onChange, className }: ShiftFilterProps) {
  return (
    <div
      role="group"
      aria-label="Filtrer på skift"
      className={cn(
        "inline-flex shrink-0 items-center rounded-[2px] border border-board/35 p-[2px]",
        className
      )}
    >
      {OPTIONS.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.label}
            type="button"
            title={option.hint}
            aria-pressed={active}
            onClick={() => onChange(option.value)}
            className={cn(
              "rounded-[1px] px-1.5 py-1 font-signage text-[8px] font-medium uppercase tracking-[0.08em] transition-colors sm:px-2.5 sm:text-[10px] sm:tracking-[0.18em]",
              active
                ? "bg-board text-flap-ink"
                : "text-board/60 hover:bg-board/10 hover:text-board"
            )}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
