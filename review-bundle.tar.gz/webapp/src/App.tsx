import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import { useAuthStatus } from "@/hooks/use-auth";

const queryClient = new QueryClient();

/** Gates the board behind the shared team login (see backend/src/lib/auth.ts). */
const RequireAuth = ({ children }: { children: JSX.Element }) => {
  const { data, isLoading } = useAuthStatus();

  // Nothing to show yet either way — avoid flashing the login form for a
  // fraction of a second on every page load for people who are already in.
  if (isLoading) return <div className="min-h-screen bg-background" />;

  return data?.authenticated ? children : <Login />;
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <RequireAuth>
                <Index />
              </RequireAuth>
            }
          />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
