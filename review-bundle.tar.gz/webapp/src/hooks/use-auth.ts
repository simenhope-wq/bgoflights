import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";

interface AuthStatus {
  authenticated: boolean;
}

/**
 * Whether this browser already carries a valid session cookie. The cookie
 * itself never expires in practice (10-year signed cookie, set on login),
 * so this really only needs to run once per page load.
 */
export function useAuthStatus() {
  return useQuery<AuthStatus>({
    queryKey: ["auth", "me"],
    queryFn: () => api.get<AuthStatus>("/api/auth/me"),
    staleTime: Infinity,
    refetchOnWindowFocus: false,
    retry: false,
  });
}
